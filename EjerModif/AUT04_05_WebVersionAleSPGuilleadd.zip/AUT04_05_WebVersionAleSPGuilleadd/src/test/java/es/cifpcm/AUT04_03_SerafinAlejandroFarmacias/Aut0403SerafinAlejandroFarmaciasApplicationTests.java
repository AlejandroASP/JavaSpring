package es.cifpcm.AUT04_03_SerafinAlejandroFarmacias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aut0403SerafinAlejandroFarmaciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
