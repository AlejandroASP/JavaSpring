package es.cifpcm.GaleriaImagenesSerafin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GaleriaImagenesSerafinApplicationTests {

	@Test
	void contextLoads() {
	}

}
